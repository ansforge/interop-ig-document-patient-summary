# ans.document.fr.ips#0.1.0: ANS IG Document IPS(fr-FR)

## Pages

* [Accueil](index.md)
* [Mapping ML/CDA/FHIR](mapping.md)
* [Autres Ressources](autres_ressources.md)
* [Exigences spécifiques](exigences-specifiques.md)
* [Fonctionnel](fonctionnel.md)
* [Sécurité](securite.md)
* [CDA](cda.md)
* [Artifacts Summary](artifacts.md)
* [Téléchargements et usages](annexe-downloads.md)
* [Cas d'usage](cas-usage.md)
* [Modèle logique métier](modele-logique-metier.md)
* [FHIR](fhir.md)
* [Informations sur la traduction](translationinfo.md)
* [Implémentations](implementations.md)

## Resources

### Logicals

* [Modèle logique métier - FR LM Patient Summary Document](StructureDefinition-fr-lm-patient-summary-document.md)

### Logical Profiles

* [CDA - clinicalDocument IPS](StructureDefinition-fr-cda-clinical-document-ips.md)

### Resource Profiles

* [Bundle (IPS)](StructureDefinition-fr-bundle-document-ips.md)
* [FR Composition Document IPS](StructureDefinition-fr-composition-document-ips.md)

### ImplementationGuides

* [ANS IG Document IPS](ImplementationGuide-ans.document.fr.ips.md)

### Examples

* [patient-summary (Binary)](Binary-patient-summary.md)
* [Bundle-IPS-FR-DLU (Bundle)](Bundle-Bundle-IPS-FR-DLU.md)
* [Bundle-IPS-FR (Bundle)](Bundle-Bundle-IPS-FR.md)
