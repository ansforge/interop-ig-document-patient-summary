# Fonctionnel - Volet de Synthèse Médicale (International Patient Summary) v0.1.0

## Fonctionnel

* [Cas d'usage](./cas-usage.md)
* [Modèle logique métier](./modele-logique-metier.md)

